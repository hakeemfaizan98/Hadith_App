package com.example.hadith_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=findViewById(R.id.listview);

        String[] title=getResources().getStringArray(R.array.Hadith_Tittle);
        final String[] explination=getResources().getStringArray(R.array.Explination);

        ArrayAdapter<String>arrayAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,title);
        listView.setAdapter(arrayAdapter );







        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
            String iss=explination[i];
                Intent ii=new Intent(MainActivity.this,Read_Material.class);
                ii.putExtra("explination",iss);
                startActivity(ii);
            }
        });
}}